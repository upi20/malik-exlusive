$(() =>
{
	$('#advanced-usage').DataTable()
})